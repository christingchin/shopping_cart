﻿Imports System.IO
Imports System.Data.OleDb
Public Class Product
    Dim strCurrentPath As String
    Public strFullDBPath As String
    Dim cmd As New OleDb.OleDbCommand
    Private Counter As Integer
    ''Dim cn As OleDbConnection = New OleDbConnection()

    Dim cn As New OleDbConnection
    Private Sub Product_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Me.CenterToScreen()
        strCurrentPath = CurDir()
        strCurrentPath = Replace(CurDir, "\bin\Debug", "")
        strFullDBPath = strCurrentPath + "\My_Data" + "\Shoppping_Cart.mdb"
        cn.ConnectionString = "Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;"
        RefreshData_tblProduct()
        Control_DGV_Column()
    End Sub

    Private Sub RefreshData_tblProduct()
        Dim cn As New OleDbConnection("Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;")
        Dim Command As OleDbCommand = New OleDbCommand
        Command.CommandText = "SELECT * FROM tbl_Product"
        Command.Connection = cn
        cn.Open()
        Dim dt As New DataTable
        dt.Load(Command.ExecuteReader())
        DataGridView1.DataSource = dt
        Me.DataGridView1.Columns("ID").Visible = False
        Me.DataGridView1.Columns("TotalPrice").Visible = False
    End Sub

    Private Sub DataGridView1_DoubleClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DataGridView1.DoubleClick

        Me.txtID.Text = DataGridView1.CurrentRow.Cells("ID").Value.ToString
        Me.txtProductID1.Text = DataGridView1.CurrentRow.Cells("ProductID").Value.ToString
        Me.txtProdutName1.Text = DataGridView1.CurrentRow.Cells("ProductName").Value.ToString
        Me.txtProductQuantity1.Text = DataGridView1.CurrentRow.Cells("Qty").Value.ToString
        Me.txtProductPrice1.Text = DataGridView1.CurrentRow.Cells("Price").Value.ToString
        '' Me.txtVendorName1.Text = DataGridView1.CurrentRow.Cells("VendorName").Value.ToString
        '' Me.txtDescription1.Text = DataGridView1.CurrentRow.Cells("Description").Value.ToString
        Me.txtProductTotalPrice1.Text = DataGridView1.CurrentRow.Cells("TotalPrice").Value.ToString
        RefreshData_tblProduct()

    End Sub

    Private Sub btnAddCart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddCart.Click

        If txtProductQuantity1.Text = Nothing Then
            MessageBox.Show("OUT OF STOCK", "Information")
            Exit Sub
        Else
            Shopping_Cart.txtSID.Text = Me.txtID.Text
            Shopping_Cart.txtUserProductID.Text = Me.txtProductID1.Text
            Shopping_Cart.txtUserProductName.Text = Me.txtProdutName1.Text
            Shopping_Cart.txtUserProductPrice.Text = Me.txtProductPrice1.Text
            Vendor_Cart()
        End If

    End Sub

    Private Sub Vendor_Cart()

        'Product Part'
        Dim ProductID As String = txtProductID1.Text 'product ID'
        Dim ProductName As String = txtProdutName1.Text 'product name'
        Dim ProductQTY As String = txtProductQuantity1.Text 'product qty'
        Dim ProductPrice As String = txtProductPrice1.Text 'product single price'
        Dim ProductTotalPrice As Double = CDbl(txtProductTotalPrice1.Text)
        'Total'
        Dim totalProduct As String = Shopping_Cart.txtUserTotalPrice.Text
        Dim deduct As Integer = 1

        My_Cart()

        Try
            If txtProductQuantity1.Text = "0" Then
                MessageBox.Show("OUT OF STOCK")
                Exit Sub
            End If
            For A = 0 To CInt(ProductQTY) 'total qty'
            Next A

            txtProductQuantity1.Text = CStr(CDbl(ProductQTY) - deduct)
            txtProductTotalPrice1.Text = CStr(CDbl(ProductTotalPrice) - CDbl(ProductPrice))

        Catch ex As Exception

        End Try

    End Sub

    Private Sub My_Cart()


        'Product'
        Dim ProductQTY As String = txtProductQuantity1.Text 'product qty'
        Dim ProductPrice As String = txtProductPrice1.Text 'product single price'

        'Count Part'
        Dim ADD_T_QTY As String = Shopping_Cart.txtUserQuantity.Text
        Dim ADD_T_Price As String = Shopping_Cart.txtUserTotalPrice.Text

        ADD_T_QTY = CStr(Int(0))
        ADD_T_Price = CStr(Int(0))

        Dim Sum As Double

        Try
            If txtProductQuantity1.Text = "0" Then
                Exit Sub
            Else
                Counter = Counter + 1
                Sum = CDbl(ADD_T_QTY)

                For i = 1 To Counter

                    Shopping_Cart.txtUserQuantity.Text = CStr(Counter + Sum)
                    Shopping_Cart.txtUserTotalPrice.Text = CStr(CDbl(ProductPrice) * Counter)
                Next i

            End If

        Catch ex As Exception

        End Try

    End Sub

    Private Sub Control_DGV_Column()

        DataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None
        Dim dic As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)()
        dic.Add("ProductID", 80)
        dic.Add("ProductName", 90)
        dic.Add("VendorName", 80)
        dic.Add("Qty", 40)
        dic.Add("Price", 40)
        dic.Add("Description", 300)
        dic.Add("TotalPrice", 80)

        For i As Integer = 0 To DataGridView1.Columns.Count - 1
            Dim s As Integer = dic.Where(Function(x) x.Key = DataGridView1.Columns(i).Name).[Select](Function(y) y.Value).FirstOrDefault
            DataGridView1.Columns(i).Width = s
        Next

    End Sub

    Private Sub txtClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        txtProductID1.Text = ""
        txtProdutName1.Text = ""
        txtProductQuantity1.Text = ""
        txtProductPrice1.Text = ""
        ''txtVendorName1.Text = ""
        ''txtDescription1.Text = ""
        RefreshData_tblProduct()
    End Sub

    Private Sub MyCartToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyCartToolStripMenuItem.Click
        Shopping_Cart.ShowDialog()
        Me.CenterToScreen()
        Me.Hide()
    End Sub

    Private Sub ToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem1.Click
        Application.Restart()
    End Sub
End Class
