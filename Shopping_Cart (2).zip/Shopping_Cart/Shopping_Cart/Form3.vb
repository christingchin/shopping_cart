﻿Public Class Form3

    Private Sub Form3_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ' lblTime.Text = GetTime(90)
        Me.CenterToScreen()
       
    End Sub
    Public Function GetTime(ByVal Time As Integer) As String
        Dim Hrs As Integer  'number of hours   '
        Dim Min As Integer  'number of Minutes '
        Dim Sec As Integer  'number of Sec     '

        'Seconds'
        Sec = Time Mod 60

        'Minutes'
        Min = CInt(((Time - Sec) / 60) Mod 60)

        'Hours'
        Hrs = CInt(((Time - (Sec + (Min * 60))) / 3600) Mod 60)


        Return Format(Hrs, "00") & ":" & Format(Min, "00") & ":" & Format(Sec, "00")

    End Function

    Dim timercount As Integer = 10 'The number of seconds 

    Private Sub btnReset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReset.Click
        Timer1.Enabled = False 'Stop the timer
        timercount = 10 'Reset to 60 seconds
        lblOutput.Text = timercount.ToString() 'Reset the output display to 60

    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick

        lblOutput.Text = timercount.ToString() 'show the countdown in the label
        If timercount = 0 Then 'Check to see if it has reached 0, if yes then stop timer and display done
            Timer1.Enabled = False
            Button1.PerformClick()
            lblOutput.Text = "Done"
        Else 'If timercount is higher then 0 then subtract one from it
            timercount -= 1

        End If
    End Sub

    Private Sub btnStart_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStart.Click

        Timer1.Interval = 1000 'The number of miliseconds in a second
        Timer1.Enabled = True 'Start the timer
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
    End Sub
End Class