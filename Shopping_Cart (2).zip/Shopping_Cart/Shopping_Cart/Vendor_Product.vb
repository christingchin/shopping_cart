﻿Imports System.Data.OleDb

Public Class Vendor_Product
    Dim strCurrentPath As String
    Public strFullDBPath As String
    Dim cmd As New OleDb.OleDbCommand
    Dim cn As New OleDbConnection

    Private Sub Vendor_Product_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.CenterToScreen()
        strCurrentPath = CurDir()
        strCurrentPath = Replace(CurDir, "\bin\Debug", "")
        strFullDBPath = strCurrentPath + "\My_Data" + "\Shoppping_Cart.mdb"
        cn.ConnectionString = "Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;"
        txtDate.Text = DateTime.Now.ToString("dd  MMMM  yyyy")
        Refresh_Product_Data()
        Control_DGV_Column1()

    End Sub

    Private Sub Control_DGV_Column1()

        DataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None
        Dim dic As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)()
        dic.Add("ID", 40)
        dic.Add("ProductID", 80)
        dic.Add("ProductName", 90)
        dic.Add("VendorName", 80)
        dic.Add("Qty", 40)
        dic.Add("Price", 40)
        dic.Add("Description", 150)
        dic.Add("TotalPrice", 80)

        For i As Integer = 0 To DataGridView1.Columns.Count - 1
            Dim s As Integer = dic.Where(Function(x) x.Key = DataGridView1.Columns(i).Name).[Select](Function(y) y.Value).FirstOrDefault
            DataGridView1.Columns(i).Width = s
        Next

    End Sub

    'Private Sub Vendor_Product_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

    '    Application.Exit()

    'End Sub

    Private Sub RefreshData_tblProduct()
        Dim cn As New OleDbConnection("Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;")
        Dim Command As OleDbCommand = New OleDbCommand
        Command.CommandText = "SELECT * FROM tbl_Product"
        Command.Connection = cn
        cn.Open()
        Dim dt As New DataTable
        dt.Load(Command.ExecuteReader())
        DataGridView1.DataSource = dt
        ' Me.DataGridView1.Columns("ID").Visible = False
    End Sub


    Private Sub RefreshData_tblVendorAddProduct()
        Dim cn As New OleDbConnection("Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;")
        Dim Command As OleDbCommand = New OleDbCommand
        Command.CommandText = "SELECT * FROM tbl_VendorAddProduct"
        Command.Connection = cn
        cn.Open()
        Dim dt As New DataTable
        dt.Load(Command.ExecuteReader())
        DataGridView1.DataSource = dt
        Me.DataGridView1.Columns("ID").Visible = False
    End Sub

    Private Sub Refresh_Product_Data()

        Dim cn As New OleDbConnection("Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;")
        Dim Command As OleDbCommand = New OleDbCommand
        Command.CommandText = "SELECT * FROM tbl_Product"
        Command.Connection = cn
        cn.Open()
        Dim dt As New DataTable
        dt.Load(Command.ExecuteReader())
        DataGridView1.DataSource = dt
        ''  Me.DataGridView1.Columns("ID").Visible = False

    End Sub

    Private Sub ProductToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ProductToolStripMenuItem.Click
        Product.ShowDialog()
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click

        If txtID.Text = "" Then
            Add_Product()
            Add_Vendor_Product()
        Else
            Edit_Product()
        End If

    End Sub

    Private Sub Add_Vendor_Product()
        Dim con As New OleDbConnection
        Dim cmd As New OleDbCommand
        Try
            con.ConnectionString = "Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;"
            con.Open()
            cmd.Connection = con
            cmd.CommandText = "INSERT INTO tbl_VendorAddProduct([ProductID],[ProductName], [VendorName],[Qty],[ProductPrice],[Date],[Description],[TotalPrice]) VALUES(@ProductID, @ProductName, @VendorName, @Qty, @ProductPrice, @Date, @Description, @TotalPrice)"

            cmd.Parameters.AddWithValue("@ProductID", Me.txtProductID.Text)
            cmd.Parameters.AddWithValue("@ProductName", Me.txtProductName.Text)
            cmd.Parameters.AddWithValue("@VendorName", Me.txtVendorName.Text)
            cmd.Parameters.AddWithValue("@Qty", Me.txtProductQty.Text)
            cmd.Parameters.AddWithValue("@ProductPrice", Me.txtProductPrice.Text)
            cmd.Parameters.AddWithValue("@Date", Me.txtDate.Text)
            cmd.Parameters.AddWithValue("@Description", Me.txtDescription.Text)
            cmd.Parameters.AddWithValue("@TotalPrice", Me.txtTotalPrice.Text)

            cmd.ExecuteNonQuery()

            MsgBox("Add Vendor_Product Successful", MsgBoxStyle.OkOnly, "Message")
            ''RefreshData_tblVendorAddProduct()
            RefreshData_tblProduct()
        Catch ex As Exception
            MessageBox.Show("Error on Vendor Product..." & ex.Message, "Insert Records")
        Finally
            con.Close()
            ''RefreshData_tblVendorAddProduct()
            RefreshData_tblProduct()
        End Try
    End Sub
    Private Sub Add_Product()
        Dim con As New OleDbConnection
        Dim cmd As New OleDbCommand
        Try
            con.ConnectionString = "Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;"
            con.Open()
            cmd.Connection = con
            cmd.CommandText = "INSERT INTO tbl_Product([ProductID],[ProductName], [VendorName],[Qty],[Price],[Description],[TotalPrice]) VALUES(@ProductID, @ProductName, @VendorName, @Qty, @ProductPrice, @Description, @TotalPrice)"

            'Control total price of product'
            Control_Qty_Price()

            cmd.Parameters.AddWithValue("@ProductID", Me.txtProductID.Text)
            cmd.Parameters.AddWithValue("@ProductName", Me.txtProductName.Text)
            cmd.Parameters.AddWithValue("@VendorName", Me.txtVendorName.Text)
            cmd.Parameters.AddWithValue("@Qty", Me.txtProductQty.Text)
            cmd.Parameters.AddWithValue("@Price", Me.txtProductPrice.Text)
            cmd.Parameters.AddWithValue("@Description", Me.txtDescription.Text)
            cmd.Parameters.AddWithValue("@TotalPrice", Me.txtTotalPrice.Text)

            cmd.ExecuteNonQuery()
            '' MsgBox("Add Product Successful", MsgBoxStyle.OkOnly, "Message")
            RefreshData_tblProduct()

        Catch ex As Exception
            MessageBox.Show("Error..." & ex.Message, "Insert Records")
        Finally
            con.Close()
            RefreshData_tblProduct()

        End Try
    End Sub

    Private Sub Edit_Product()
        Dim con As New OleDbConnection
        Dim cmd As New OleDbCommand
        Try
            con.ConnectionString = "Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;"
            con.Open()
            cmd.Connection = con

            cmd.CommandText = "UPDATE tbl_Product SET ProductID = @ProductID, ProductName = @ProductName, VendorName = @VendorName, Qty = @Qty, Price = @Price, Description = @Description, TotalPrice = @TotalPrice Where ID = " & txtID.Text

            Control_Qty_Price()

            cmd.Parameters.AddWithValue("@ProductID", Me.txtProductID.Text)
            cmd.Parameters.AddWithValue("@ProductName", Me.txtProductName.Text)
            cmd.Parameters.AddWithValue("@VendorName", Me.txtVendorName.Text)
            cmd.Parameters.AddWithValue("@Qty", Me.txtProductQty.Text)
            cmd.Parameters.AddWithValue("@Price", Me.txtProductPrice.Text)
            cmd.Parameters.AddWithValue("@Description", Me.txtDescription.Text)
            cmd.Parameters.AddWithValue("@TotalPrice", Me.txtTotalPrice.Text)

            cmd.ExecuteNonQuery()


            MessageBox.Show("You data have been update successful", "Information")
            RefreshData_tblProduct()

        Catch ex As Exception
            MessageBox.Show("Error while update record on table..." & ex.Message, "Update Records")
        Finally
            con.Close()
            RefreshData_tblProduct()

        End Try
    End Sub

    Private Sub Control_Qty_Price()
        Dim QTY As Integer = CInt(txtProductQty.Text)
        Dim Price As Double = CDbl(txtProductPrice.Text)
        Dim Total As String = txtTotalPrice.Text
        Dim Product_Name As String = txtProductName.Text

        Total = CStr(QTY * Price)
        Dim Message = "Total Price = " + Total + "  " + Product_Name

        txtTotalPrice.Text = Total
        MsgBox(Message, MsgBoxStyle.OkOnly, "Information")
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        Me.btnSave.Text = "Save"
        Me.btnSave.Enabled = True

        Refresh_Product_Data()

        txtProductID.Text = ""
        txtProductName.Text = ""
        txtVendorName.Text = ""
        txtProductQty.Text = ""
        txtProductPrice.Text = ""
        txtDescription.Text = ""
        txtTotalPrice.Text = ""
        txtID.Text = ""
    End Sub

    Private Sub txtSProductIDVendor_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtSProductIDVendor.TextChanged
        Dim cnn1 As New OleDb.OleDbConnection
        cnn1.ConnectionString = "Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;"
        If Not cnn1.State = ConnectionState.Open Then
        End If
        cnn1.Open()
        Dim dt As New DataTable
        Dim ds As New DataSet
        ds.Tables.Add(dt)
        Dim da As New OleDbDataAdapter

        da = New OleDbDataAdapter("SELECT * FROM tbl_VendorAddProduct WHERE ProductID like '%" & txtSProductIDVendor.Text & "%'", cnn1)
        da.Fill(dt)

        DataGridView1.DataSource = dt.DefaultView
        cnn1.Close()
    End Sub

    Private Sub DataGridView1_CellDoubleClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellDoubleClick
        Me.btnSave.Text = "Update"
        Me.btnSave.Enabled = True

        Me.txtID.Text = DataGridView1.CurrentRow.Cells("ID").Value.ToString
        Me.txtProductID.Text = DataGridView1.CurrentRow.Cells("ProductID").Value.ToString
        Me.txtProductName.Text = DataGridView1.CurrentRow.Cells("ProductName").Value.ToString
        Me.txtVendorName.Text = DataGridView1.CurrentRow.Cells("VendorName").Value.ToString
        Me.txtProductQty.Text = DataGridView1.CurrentRow.Cells("Qty").Value.ToString
        Me.txtProductPrice.Text = DataGridView1.CurrentRow.Cells("Price").Value.ToString
        Me.txtDescription.Text = DataGridView1.CurrentRow.Cells("Description").Value.ToString
        Me.txtTotalPrice.Text = DataGridView1.CurrentRow.Cells("TotalPrice").Value.ToString

        btnSave.Enabled = True
        RefreshData_tblProduct()
    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        Dim ID As String
        ID = txtID.Text

        txtID.Text = ID
        If txtID.Text = Nothing Then
            MessageBox.Show("Pls Select Data Correctly", "Information")
        Else
            HandleSetSettingStatus()
        End If

    End Sub

    Public Sub HandleSetSettingStatus()

        strFullDBPath = strCurrentPath + "\My_Data" + "\Shoppping_Cart.mdb"

        Dim connection As New OleDbConnection("Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;")
        Dim command As New OleDbCommand("DELETE FROM tbl_Product WHERE ID = @ID", connection)
        Select Case MsgBox("Did you sure you want to delete this data", MsgBoxStyle.YesNo, "Message Confirmation")
            Case MsgBoxResult.Yes
                MessageBox.Show("Your data have been deleted", "Message")
            Case MsgBoxResult.No
                MessageBox.Show("Your data have been keep", "Message")
                Exit Sub
        End Select
        MessageBox.Show("Delete data successful")
        command.Parameters.Add("@id", OleDbType.Char).Value = txtID.Text
        connection.Open()
        If command.ExecuteNonQuery() = 1 Then

        End If
        connection.Close()
        RefreshData_tblProduct()
        btnClear.PerformClick()
    End Sub

    Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
        If txtID.Text = Nothing Then
            MessageBox.Show("Pls make sure your key in ProductID correctly", "Information")
            Exit Sub
        Else
            Vendor_Add_Stock.txtID.Text = Me.txtID.Text
            Vendor_Add_Stock.txtProductID.Text = Me.txtProductID.Text
            Vendor_Add_Stock.txtProductName.Text = Me.txtProductName.Text
            Vendor_Add_Stock.txtVendorName.Text = Me.txtVendorName.Text
            Vendor_Add_Stock.txtProductPrice.Text = Me.txtProductPrice.Text
            Vendor_Add_Stock.ShowDialog()
        End If

    End Sub

    Private Sub btnView_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnView.Click
        CenterToParent()

        btnClear.PerformClick()
        Vendor_Add_Stock.Show()
        Vendor_Add_Stock.btnClear.PerformClick()
        Me.btnSave.Text = "VIEW"
        Me.btnSave.Enabled = True

    End Sub
End Class