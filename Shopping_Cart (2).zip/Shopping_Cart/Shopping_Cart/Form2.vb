﻿Imports System.Threading.Tasks
Imports System.Data.OleDb
Imports System.Data.SqlClient


Public Class Form2
    Dim strCurrentPath As String
    Public strFullDBPath As String
    Dim cmd As New OleDb.OleDbCommand

    Dim cn As New OleDbConnection

    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.CenterToScreen()
        strCurrentPath = CurDir()
        strCurrentPath = Replace(CurDir, "\bin\Debug", "")
        strFullDBPath = strCurrentPath + "\My_Data" + "\Shoppping_Cart.mdb"
        cn.ConnectionString = "Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;"
        RefreshData_tblShoppingCart()
        RefreshData_tblProduct()

        '' CheckBox()
        '' BindGrid()
    End Sub

    Private Sub Textbox_Retrieve_Data()

        Dim constr As String = "Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;"
        Using con As OleDbConnection = New OleDbConnection(constr)
           '' Using cmd As OleDbCommand = New OleDbCommand("SELECT Qty, Price, TotalPrice FROM tbl_Product WHERE ProductID = IPHONE11")
            ''Using cmd As OleDbCommand = New OleDbCommand("SELECT ID, ProductID, ProductName, VendorName, Qty, Price, Description, TotalPrice FROM tbl_Product WHERE ID = 12")
            Using cmd As OleDbCommand = New OleDbCommand("SELECT ID, ProductID, ProductName, VendorName, Qty, Price, Description, TotalPrice FROM tbl_Product WHERE ID = " + TextBox1.Text)
                cmd.CommandType = CommandType.Text
                cmd.Connection = con
                con.Open()
                Using sdr As OleDbDataReader = cmd.ExecuteReader()
                    sdr.Read()
                    TextBox2.Text = sdr("ProductID").ToString
                    TextBox3.Text = sdr("Qty").ToString()
                    TextBox4.Text = sdr("Price").ToString()
                    TextBox5.Text = sdr("TotalPrice").ToString()
                End Using
                con.Close()
            End Using
        End Using
    End Sub

    Private Sub RefreshData_tblProduct()
        Dim cn As New OleDbConnection("Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;")
        Dim Command As OleDbCommand = New OleDbCommand
        Command.CommandText = "SELECT * FROM tbl_Product"
        Command.Connection = cn
        cn.Open()
        Dim dt As New DataTable
        dt.Load(Command.ExecuteReader())
        DataGridView1.DataSource = dt
        Me.DataGridView1.Columns("ID").Visible = False
        Me.DataGridView1.Columns("TotalPrice").Visible = False
    End Sub

    Public Sub CheckBox()

        Dim AddColumn As New DataGridViewCheckBoxColumn

        With AddColumn
            .HeaderText = "Check Out"
            .Name = "Check Out"
            .Width = 80
        End With

        DataGridView1.Columns.Insert(1, AddColumn)
    End Sub

    Private Sub RefreshData_tblShoppingCart()

        Dim cn As New OleDbConnection("Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;")
        Dim Command As OleDbCommand = New OleDbCommand
        Command.CommandText = "SELECT * FROM tbl_Cart"
        Command.Connection = cn
        cn.Open()
        Dim dt As New DataTable
        dt.Load(Command.ExecuteReader())
        DataGridView1.DataSource = dt
        Me.DataGridView1.Columns("ID").Visible = False

    End Sub

    Private Sub BindGrid()
        Using con As OleDbConnection = New OleDbConnection("Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;")

            Using cmd As OleDbCommand = New OleDbCommand("SELECT * FROM tbl_Cart", con)
                cmd.CommandType = CommandType.Text

                Using sda As OleDbDataAdapter = New OleDbDataAdapter(cmd)

                    Using dt As DataTable = New DataTable()
                        sda.Fill(dt)
                        DataGridView1.DataSource = dt
                    End Using
                End Using
            End Using
        End Using

        Dim checkBoxColumn As DataGridViewCheckBoxColumn = New DataGridViewCheckBoxColumn()
        checkBoxColumn.HeaderText = "CheckOut"
        checkBoxColumn.Width = 80
        checkBoxColumn.Name = "checkBoxColumn"
        DataGridView1.Columns.Insert(0, checkBoxColumn)

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim dt As DataTable = New DataTable()
        dt.Columns.Add("ProductID")
        dt.Columns.Add("ProductName")
        dt.Columns.Add("CustomerName")

        For Each row As DataGridViewRow In DataGridView1.Rows
            Dim isSelected As Boolean = Convert.ToBoolean(row.Cells("checkBoxColumn").Value)

            If isSelected Then
                dt.Rows.Add(row.Cells(1).Value, row.Cells(2).Value, row.Cells(3).Value)
            End If
        Next

        DataGridView2.DataSource = dt

    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        'Dim cnn1 As New OleDb.OleDbConnection
        'cnn1.ConnectionString = "Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;"
        'If Not cnn1.State = ConnectionState.Open Then
        'End If
        'cnn1.Open()
        'Dim dt As New DataTable
        'Dim ds As New DataSet
        'ds.Tables.Add(dt)
        'Dim da As New OleDbDataAdapter

        'da = New OleDbDataAdapter("SELECT * FROM tbl_Product WHERE ProductID like '%" & TextBox1.Text & "%'", cnn1)
        'da.Fill(dt)

        'DataGridView1.DataSource = dt.DefaultView
        'cnn1.Close()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Textbox_Retrieve_Data()
    End Sub
End Class