﻿Imports System.Data.OleDb

Public Class Shopping_Cart

    Dim strCurrentPath As String
    Public strFullDBPath As String
    Dim cmd As New OleDb.OleDbCommand
    Dim cn As New OleDbConnection

    Private Sub ShoppingCart_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.CenterToScreen()
        strCurrentPath = CurDir()
        strCurrentPath = Replace(CurDir, "\bin\Debug", "")
        strFullDBPath = strCurrentPath + "\My_Data" + "\Shoppping_Cart.mdb"
        cn.ConnectionString = "Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;"

        RefreshData_tblShoppingCart()
        Control_DGV_Column()
        BindGrid()
    End Sub


    Public Sub CheckBox()

        Dim AddColumn As New DataGridViewCheckBoxColumn

        With AddColumn
            .HeaderText = "Check Out"
            .Name = "Check Out"
            .Width = 80
        End With

        DataGridView1.Columns.Insert(1, AddColumn)
    End Sub

    Private Sub DataGridView1_CellDoubleClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs)

        Me.txtID.Text = DataGridView1.CurrentRow.Cells("ID").Value.ToString
        RefreshData_tblShoppingCart()

    End Sub

    Private Sub Control_DGV_Column()

        DataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None
        Dim dic As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)()

        dic.Add("Check Out", 70)
        dic.Add("ProductID", 80)
        dic.Add("ProductName", 90)
        dic.Add("CustomerName", 80)
        dic.Add("Cart_Qty", 80)
        dic.Add("Price", 80)
        dic.Add("Total_Price", 80)


        For i As Integer = 0 To DataGridView1.Columns.Count - 1
            Dim s As Integer = dic.Where(Function(x) x.Key = DataGridView1.Columns(i).Name).[Select](Function(y) y.Value).FirstOrDefault
            DataGridView1.Columns(i).Width = s
        Next

    End Sub

    Private Sub RefreshData_tblShoppingCart()

        Dim cn As New OleDbConnection("Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;")
        Dim Command As OleDbCommand = New OleDbCommand
        Command.CommandText = "SELECT * FROM tbl_Cart"
        Command.Connection = cn
        cn.Open()
        Dim dt As New DataTable
        dt.Load(Command.ExecuteReader())
        DataGridView1.DataSource = dt
        Me.DataGridView1.Columns("ID").Visible = False
        Me.DataGridView1.Columns("SID").Visible = False
    End Sub

    Private Sub Clear_TextBox()

        txtID.Text = ""
        txtUserProductID.Text = ""
        txtUserProductName.Text = ""
        txtUserProductPrice.Text = ""
        txtUserQuantity.Text = ""
        txtUserTotalPrice.Text = ""

        txtShoppingCartPrice.Text = ""
        txtShoppingCartQty.Text = ""
        txtShoppingProductID.Text = ""
        txtSID.Text = ""
        txtTotalShoppingCartPrice.Text = ""
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Try
            Save_Cart()
            Update_tbl_Product()
            Product.btnClear.PerformClick()
            RefreshData_tblShoppingCart()
            Clear_TextBox()
        Catch ex As Exception
            MessageBox.Show("Pls make sure your key in data properly", "Information")
        End Try
    End Sub

    Private Sub Save_Cart()

        Dim con As New OleDbConnection
        Dim cmd As New OleDbCommand
        Try
            con.ConnectionString = "Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;"
            con.Open()
            cmd.Connection = con
            cmd.CommandText = "INSERT INTO tbl_Cart([SID],[ProductID],[ProductName], [CustomerName],[Cart_Qty],[Price],[Total_Price]) VALUES(@SID, @ProductID, @ProductName, @CustomerName, @Cart_Qty, @Price, @Total_Price)"

            cmd.Parameters.AddWithValue("@SID", Me.txtSID.Text)
            cmd.Parameters.AddWithValue("@ProductID", Me.txtUserProductID.Text)
            cmd.Parameters.AddWithValue("@ProductName", Me.txtUserProductName.Text)
            cmd.Parameters.AddWithValue("@CustomerName", Me.txtCustomerName.Text)
            cmd.Parameters.AddWithValue("@Cart_Qty", Me.txtUserQuantity.Text)
            cmd.Parameters.AddWithValue("@Price", Me.txtUserProductPrice.Text)
            cmd.Parameters.AddWithValue("@Total_Price", Me.txtUserTotalPrice.Text)

            cmd.ExecuteNonQuery()
            MsgBox("Success add product to shopping cart", MsgBoxStyle.OkOnly, "Message")
            RefreshData_tblShoppingCart()

        Catch ex As Exception
            MessageBox.Show("Error add product to shopping cart..." & ex.Message, "Insert Records")
        Finally
            con.Close()
            RefreshData_tblShoppingCart()

        End Try
    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        HandleSetSettingStatus()
    End Sub

    Private Sub HandleSetSettingStatus()

        strFullDBPath = strCurrentPath + "\My_Data" + "\Shoppping_Cart.mdb"

        Dim connection As New OleDbConnection("Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;")

        Dim command As New OleDbCommand("DELETE FROM tbl_Cart WHERE ID = @ID", connection)

        'Select Case MsgBox("Did you sure you want to delete this data", MsgBoxStyle.YesNo, "Message Confirmation")
        '    Case MsgBoxResult.Yes
        '        MessageBox.Show("Your data have been deleted", "Message")
        '    Case MsgBoxResult.No
        '        MessageBox.Show("Your data have been keep", "Message")
        '        Exit Sub
        'End Select

        MessageBox.Show("Pls Come Again")
        command.Parameters.Add("@id", OleDbType.Char).Value = txtID.Text
        connection.Open()
        If command.ExecuteNonQuery() = 1 Then

        End If
        connection.Close()
        RefreshData_tblShoppingCart()
        txtID.Text = ""
        txtShoppingCartQty.Text = ""
    End Sub

    Private Sub Update_tbl_Product()

        Dim con As New OleDbConnection
        Dim cmd As New OleDbCommand
        Try
            con.ConnectionString = "Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;"
            con.Open()
            cmd.Connection = con

            ''cmd.CommandText = "UPDATE tbl_Product SET ProductID = @ProductID, ProductName = @ProductName, VendorName = @VendorName, Qty = @Qty, Price = @Price, Description = @Description, TotalPrice = @TotalPrice Where ID = " & Product.txtID.Text
            cmd.CommandText = "UPDATE tbl_Product SET ProductID = @ProductID, ProductName = @ProductName, Qty = @Qty, Price = @Price, TotalPrice = @TotalPrice Where ID = " & Product.txtID.Text

            cmd.Parameters.AddWithValue("@ProductID", Product.txtProductID1.Text)
            cmd.Parameters.AddWithValue("@ProductName", Product.txtProdutName1.Text)
            cmd.Parameters.AddWithValue("@Qty", Product.txtProductQuantity1.Text)
            cmd.Parameters.AddWithValue("@Price", Product.txtProductPrice1.Text)
            cmd.Parameters.AddWithValue("@TotalPrice", Product.txtProductTotalPrice1.Text)

            cmd.ExecuteNonQuery()


            '' MessageBox.Show("You add this item to shoppping cart", "Information")

        Catch ex As Exception
            MessageBox.Show("Error..." & ex.Message, "Update Records")
        Finally
            con.Close()

        End Try

    End Sub

    Private Sub ToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        Payment.ShowDialog()

    End Sub

    Private Sub HomeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HomeToolStripMenuItem.Click
        Home.ShowDialog()
        Me.Hide()
    End Sub

    Private Sub DataGridView1_CellClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        Try
            If e.RowIndex >= 0 Then
                Dim row As DataGridViewRow
                row = Me.DataGridView1.Rows(e.RowIndex)

                Me.txtID.Text = row.Cells("ID").Value.ToString
                Me.txtSID.Text = row.Cells("SID").Value.ToString
                Me.txtShoppingProductID.Text = row.Cells("ProductID").Value.ToString
                Me.txtShoppingCartQty.Text = row.Cells("Cart_Qty").Value.ToString
                Me.txtShoppingCartPrice.Text = row.Cells("Price").Value.ToString
                Me.txtTotalShoppingCartPrice.Text = row.Cells("Total_Price").Value.ToString

            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub btnCancel_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Dim ID As String
        ID = txtID.Text

        txtID.Text = ID
        If txtID.Text = Nothing Then
            MessageBox.Show("Pls Select Data Correctly", "Information")
        Else
            Product.txtID.Text = Me.txtID.Text
            Textbox_Retrieve_Data()
            Return_Product()

        End If
    End Sub

    Private Sub RefreshData_tblProduct()
        Dim cn As New OleDbConnection("Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;")
        Dim Command As OleDbCommand = New OleDbCommand
        Command.CommandText = "SELECT * FROM tbl_Product"
        Command.Connection = cn
        cn.Open()
        Dim dt As New DataTable
        dt.Load(Command.ExecuteReader())
        Product.DataGridView1.DataSource = dt
        Product.DataGridView1.Columns("ID").Visible = False
        Product.DataGridView1.Columns("TotalPrice").Visible = False
    End Sub

    Private Sub TotalShopping_Cart_Qty()

        Dim ProductQTY As Integer = CInt(Product.txtProductQuantity1.Text)
        Dim ShoppingCartQTY As Integer = CInt(Me.txtShoppingCartQty.Text)

        txtShoppingCartQty.Text = CStr(ProductQTY + ShoppingCartQTY)

    End Sub

    Private Sub BindGrid()
        Using con As OleDbConnection = New OleDbConnection("Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;")

            Using cmd As OleDbCommand = New OleDbCommand("SELECT * FROM tbl_Cart", con)
                cmd.CommandType = CommandType.Text

                Using sda As OleDbDataAdapter = New OleDbDataAdapter(cmd)

                    Using dt As DataTable = New DataTable()
                        sda.Fill(dt)
                        DataGridView1.DataSource = dt
                    End Using

                    Dim checkBoxColumn As DataGridViewCheckBoxColumn = New DataGridViewCheckBoxColumn()
                    checkBoxColumn.HeaderText = "CheckOut"
                    checkBoxColumn.Width = 80
                    checkBoxColumn.Name = "checkBoxColumn"
                    DataGridView1.Columns.Insert(0, checkBoxColumn)

                End Using
            End Using
        End Using

        'Dim checkBoxColumn As DataGridViewCheckBoxColumn = New DataGridViewCheckBoxColumn()
        'checkBoxColumn.HeaderText = "CheckOut"
        'checkBoxColumn.Width = 80
        'checkBoxColumn.Name = "checkBoxColumn"
        'DataGridView1.Columns.Insert(0, checkBoxColumn)

    End Sub

    Private Sub PaymentToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PaymentToolStripMenuItem.Click

        btnSubmit.PerformClick()
        Home.Hide()
        User_Order.Show()
        '' Home.Hide()
    End Sub

    Private Sub btnSubmit_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSubmit.Click

        Dim dt As DataTable = New DataTable()
        dt.Columns.Add("ID")
        dt.Columns.Add("SID")
        dt.Columns.Add("ProductID")
        dt.Columns.Add("ProductName")
        dt.Columns.Add("CustomerName")
        dt.Columns.Add("Cart_Qty")
        dt.Columns.Add("Price")
        dt.Columns.Add("Total_Price")

        For Each row As DataGridViewRow In DataGridView1.Rows
            Dim isSelected As Boolean = Convert.ToBoolean(row.Cells("checkBoxColumn").Value)

            If isSelected Then
                dt.Rows.Add(row.Cells(1).Value, row.Cells(2).Value, row.Cells(3).Value, row.Cells(4).Value, row.Cells(5).Value, row.Cells(6).Value, row.Cells(7).Value, row.Cells(8).Value)
            End If
        Next

        'DataGridView2.DataSource = dt

        'Exit Sub
        User_Order.DataGridView2.DataSource = dt
        User_Order.Show()
        Me.CenterToScreen()

    End Sub

    Private Sub Return_Product()

        Dim con As New OleDbConnection
        Dim cmd As New OleDbCommand
        Try
            con.ConnectionString = "Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;"
            con.Open()
            cmd.Connection = con

            cmd.CommandText = "UPDATE tbl_Product SET ProductID = @ProductID, Qty = @Qty, Price = @Price, TotalPrice = @TotalPrice Where ID = " & txtSID.Text

            cmd.Parameters.AddWithValue("@ProductID", Me.txtShoppingProductID.Text)

            TotalShopping_Cart_Qty()

            cmd.Parameters.AddWithValue("@Qty", Me.txtShoppingCartQty.Text)

            cmd.Parameters.AddWithValue("@Price", Me.txtShoppingCartPrice.Text)

            TotalShopping_Cart_TotalPrice()

            cmd.Parameters.AddWithValue("@TotalPrice", Me.txtTotalShoppingCartPrice.Text)

            cmd.ExecuteNonQuery()


            MessageBox.Show("You data have been cancel successful", "Information")
            Product.btnClear.PerformClick()

        Catch ex As Exception
            MessageBox.Show("Error while cancel record on table..." & ex.Message, "Update Records")
        Finally
            con.Close()
            Product.btnClear.PerformClick()

        End Try

        HandleSetSettingStatus()

    End Sub

    Private Sub Control_Qty_Price()

        Dim QTY As Integer = CInt(txtShoppingCartQty.Text)
        Dim Price As Double = CDbl(txtShoppingCartPrice.Text)
        Dim Total As String = txtTotalShoppingCartPrice.Text
        Dim Product_Name As String = txtShoppingProductID.Text

        Total = CStr(QTY * Price)
        Dim Message = "You already cancel this Product = " + Product_Name

        txtTotalShoppingCartPrice.Text = Total
        MsgBox(Message, MsgBoxStyle.OkOnly, "Information")
        MessageBox.Show("You already cancel this Item")
    End Sub

    Private Sub ProductToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ProductToolStripMenuItem.Click
        'Product.Show()
        Product.btnClear.PerformClick()
        Application.Restart()

    End Sub

    Private Sub TotalShopping_Cart_TotalPrice()

        Dim TotalProductPrice As Double = CDbl(Product.txtProductTotalPrice1.Text)
        Dim TotalShoppingCartPrice As Double = CDbl(Me.txtTotalShoppingCartPrice.Text)

        txtTotalShoppingCartPrice.Text = CStr(TotalProductPrice + TotalShoppingCartPrice)


    End Sub

    Private Sub Textbox_Retrieve_Data()

        Dim constr As String = "Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;"
        Using con As OleDbConnection = New OleDbConnection(constr)
            Using cmd As OleDbCommand = New OleDbCommand("SELECT ID, ProductID, ProductName, VendorName, Qty, Price, Description, TotalPrice FROM tbl_Product WHERE ID = " + txtSID.Text)
                cmd.CommandType = CommandType.Text
                cmd.Connection = con
                con.Open()
                Using sdr As OleDbDataReader = cmd.ExecuteReader()
                    sdr.Read()
                    Product.txtProductID1.Text = sdr("ProductID").ToString
                    Product.txtProductQuantity1.Text = sdr("Qty").ToString()
                    Product.txtProductPrice1.Text = sdr("Price").ToString()
                    Product.txtProductTotalPrice1.Text = sdr("TotalPrice").ToString()
                End Using
                con.Close()
            End Using
        End Using

    End Sub

    Private Sub DEBUG_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim con As OleDbConnection = New OleDbConnection("Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;")
        Dim cmd As OleDbCommand = New OleDbCommand("Delete * from tbl_Cart", con)
        con.Open()
        cmd.ExecuteNonQuery()
        con.Close()
        RefreshData_tblShoppingCart()
    End Sub

    Private Sub HistoryToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HistoryToolStripMenuItem.Click
        History.ShowDialog()
    End Sub

    Private Sub ToolStripMenuItem1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem1.Click
        Application.Restart()
    End Sub

    'TIMER'

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick

        lblOutput.Text = timercount.ToString() 'show the countdown in the label
        If timercount = 0 Then 'Check to see if it has reached 0, if yes then stop timer and display done
            Timer1.Enabled = False
            lblOutput.Text = "Done"
            btnCancel.PerformClick()
            MessageBox.Show("Your order has been canceled", "Information")
        Else 'If timercount is higher then 0 then subtract one from it
            timercount -= 1

        End If
    End Sub

    Public Function GetTime(ByVal Time As Integer) As String
        Dim Hrs As Integer  'number of hours   '
        Dim Min As Integer  'number of Minutes '
        Dim Sec As Integer  'number of Sec     '

        'Seconds'
        Sec = Time Mod 60

        'Minutes'
        Min = CInt(((Time - Sec) / 60) Mod 60)

        'Hours'
        Hrs = CInt(((Time - (Sec + (Min * 60))) / 3600) Mod 60)


        Return Format(Hrs, "00") & ":" & Format(Min, "00") & ":" & Format(Sec, "00")

    End Function

    Dim timercount As Integer = 10 'The number of seconds 

    Private Sub btnStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStart.Click

        Timer1.Interval = 1000 'The number of miliseconds in a second
        Timer1.Enabled = True 'Start the timer
    End Sub

    Private Sub btnReset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReset.Click

        Timer1.Enabled = False 'Stop the timer
        timercount = 10 'Reset to 60 seconds
        lblOutput.Text = timercount.ToString() 'Reset the output display to 60

    End Sub

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged

        Dim SelectedWays
        SelectedWays = 0
        For i = 0 To DataGridView1.RowCount - 1
            If CheckBox1.Checked = True Then
                DataGridView1.Item(0, i).Value = True
                SelectedWays = SelectedWays + 1
            Else
                DataGridView1.Item(0, i).Value = False
            End If
        Next

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        CheckBox1.Checked = True

        For Each row As DataGridViewRow In DataGridView1.Rows
            Dim chk As DataGridViewCheckBoxCell = CType(row.Cells(0), DataGridViewCheckBoxCell)
            If chk.Value = True Then

                Using con As New OleDbConnection
                    Dim cmd As New OleDbCommand
                    con.ConnectionString = "Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;"
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "UPDATE tbl_Product SET ProductID = @ProductID, ProductName = @ProductName, Qty = @Cart_Qty, Price = @Price, TotalPrice = @Total_Price Where ID = " & Convert.ToInt32(row.Cells("SID").Value)
                    cmd.Parameters.AddWithValue("@ProductID", row.Cells("ProductID").Value.ToString)
                    cmd.Parameters.AddWithValue("@ProductName", row.Cells("ProductName").Value.ToString)
                    cmd.Parameters.AddWithValue("@Qty", row.Cells("Cart_Qty").Value.ToString)
                    cmd.Parameters.AddWithValue("@Price", row.Cells("Price").Value.ToString)
                    cmd.Parameters.AddWithValue("@TotalPrice", row.Cells("Total_Price").Value.ToString)
                    cmd.ExecuteNonQuery()

                End Using
            End If
        Next
        MessageBox.Show("Update successfully!")
    End Sub

    'Private Sub TestReturnAndUpdateAllData()
    '      Dim constr As String = "Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;"
    '    Using con As OleDbConnection = New OleDbConnection(constr)
    '        ' Dim sc As OleDbCommand = New OleDbCommand("UPDATE MyTable SET confirm=0 WHERE empname = @empname", con)
    '        Dim sc As OleDbCommand = New OleDbCommand("UPDATE tbl_Product SET ProductID = @ProductID, Qty = @Qty, Price = @Price, TotalPrice = @TotalPrice WHERE ID = @ID", con)
    '        con.Open()

    '        For Each name As String In List
    '            sc.Parameters.Clear()
    '            sc.Parameters.AddWithValue("@empname", name)
    '            sc.ExecuteNonQuery()
    '        Next
    '    End Using
    'End Sub

End Class