﻿Imports System.Threading.Tasks
Imports System.Threading

Public Class Form1


    Private Counter As Integer

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim A As Double
        Dim B As Double
        Dim C As Double

        A = CDbl(TextBox1.Text)
        B = CDbl(TextBox2.Text)
        C = CDbl(TextBox3.Text)

        CART()

        'Count Part'
        Dim Deduct_A_QTY As String = TextBox1.Text
        Dim Deduct_C_Price As String = TextBox2.Text
        Dim DEDUCT As Integer = 1

        Try
            If TextBox1.Text = "0" Then
                MessageBox.Show("OUT OF STOCK")
                Exit Sub
            End If
            For A = 0 To CInt(A) 'total qty'
            Next A

        Catch ex As Exception

        End Try

        TextBox1.Text = CStr(CDbl(Deduct_A_QTY) - DEDUCT)
        TextBox3.Text = CStr(C - B)

    End Sub
    'DIRECT SAVE TO DATABASE '
    Private Sub CART()
        Dim A As Integer 'A 值呈现在 Textbox1.Text
        Dim B As Double

        A = CInt(TextBox1.Text) 'QTY
        B = CDbl(TextBox2.Text) 'SINGEL PRICE

        Dim A1 As Integer = 0 ' qty product 
        'Count Part'
        Dim ADD_T_QTY As String = TextBox4.Text
        Dim ADD_T_Price As String = TextBox5.Text

        ADD_T_QTY = CStr(Int(0))
        ADD_T_Price = CStr(Int(0))

        Dim Sum As Double

        Try
            If TextBox1.Text = "0" Then
                Exit Sub
            Else
                Counter = Counter + 1
                Sum = CDbl(ADD_T_QTY)

                For i = 1 To Counter

                    TextBox4.Text = CStr(Counter + Sum)
                    TextBox5.Text = CStr(B * Counter)
                Next i

            End If


        Catch ex As Exception

        End Try
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.CenterToScreen()
    End Sub
End Class