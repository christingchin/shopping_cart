﻿Imports System.Data.OleDb
Imports System.ComponentModel
Imports System.Net.Mime.MediaTypeNames

Public Class Vendor_Add_Stock
    Dim strCurrentPath As String
    Public strFullDBPath As String
    Dim cmd As New OleDb.OleDbCommand
    Dim cnn As New OleDbConnection


    Private Sub Vendor_Add_Stock_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.CenterToScreen()
        Me.CenterToScreen()
        strCurrentPath = CurDir()
        strCurrentPath = Replace(CurDir, "\bin\Debug", "")
        strFullDBPath = strCurrentPath + "\My_Data" + "\Shoppping_Cart.mdb"
        cnn.ConnectionString = "Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;"
        txtDate.Text = DateTime.Now.ToString("dd  MMMM  yyyy")
        RefreshData_tblVendorAddProduct()
        Control_DGV_Column1()
        'txtProductPrice.Enabled = True
        Control_DGV_PAGING()

    End Sub

    Dim pagingAdapter As OleDbDataAdapter
    Dim pagingDS As DataSet
    Dim scrollVal As Integer
    Dim sql As String = "SELECT * FROM tbl_VendorAddProduct ORDER BY ID"

    Private Sub btnPrevious_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrevious.Click

        RefreshData_tblVendorAddProduct()
        Control_DGV_PAGING()
        scrollVal = scrollVal - 5
        If scrollVal <= 0 Then
            scrollVal = 0
        End If
        pagingDS.Clear()
        pagingAdapter.Fill(pagingDS, scrollVal, 5, "tbl_VendorAddProduct")

    End Sub

    Private Sub btnNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNext.Click

        RefreshData_tblVendorAddProduct()
        Control_DGV_PAGING()
        scrollVal = scrollVal + 5
        If scrollVal > 1000000 Then
            scrollVal = 1
        End If
        pagingDS.Clear()
        pagingAdapter.Fill(pagingDS, scrollVal, 5, "tbl_VendorAddProduct")

    End Sub


    Sub Control_DGV_PAGING()

        Dim connection As New OleDbConnection("Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;")
        pagingAdapter = New OleDbDataAdapter(sql, connection)
        pagingDS = New DataSet()
        connection.Open()
        pagingAdapter.Fill(pagingDS, scrollVal, 5, "tbl_VendorAddProduct")
        connection.Close()
        DataGridView1.DataSource = pagingDS
        DataGridView1.DataMember = "tbl_VendorAddProduct"
        DataGridView1.Sort(DataGridView1.Columns(0), ListSortDirection.Descending)
    End Sub

    Private Sub Control_DGV_Column1()

        DataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None
        Dim dic As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)()
        dic.Add("ID", 40)
        dic.Add("ProductID", 80)
        dic.Add("ProductName", 90)
        dic.Add("VendorName", 80)
        dic.Add("Qty", 40)
        dic.Add("ProductPrice", 80)
        dic.Add("Date", 100)
        dic.Add("Description", 150)
        dic.Add("TotalPrice", 80)

        For i As Integer = 0 To DataGridView1.Columns.Count - 1
            Dim s As Integer = dic.Where(Function(x) x.Key = DataGridView1.Columns(i).Name).[Select](Function(y) y.Value).FirstOrDefault
            DataGridView1.Columns(i).Width = s
        Next

    End Sub

    'Private Sub Vendor_Add_Stock_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

    '    Application.Exit()

    'End Sub

    Private Sub RefreshData_tblVendorAddProduct()
        Dim cn As New OleDbConnection("Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;")
        Dim Command As OleDbCommand = New OleDbCommand
        Command.CommandText = "SELECT * FROM tbl_VendorAddProduct"
        Command.Connection = cn
        cn.Open()
        Dim dt As New DataTable
        dt.Load(Command.ExecuteReader())
        DataGridView1.DataSource = dt
        Me.DataGridView1.Columns("ID").Visible = False

    End Sub

    Private Sub Control_Qty_Price()
        Dim QTY As Integer = CInt(txtProductQty.Text)
        Dim Price As Double = CDbl(txtProductPrice.Text)
        Dim Total As String = txtTotalPrice.Text
        Dim Product_Name As String = txtProductName.Text

        Total = CStr(QTY * Price)
        Dim Message = "Total Price = " + Total + "  " + Product_Name

        txtTotalPrice.Text = Total
        MsgBox(Message, MsgBoxStyle.OkOnly, "Information")
    End Sub

    Private Sub Add_Product()
        Dim con As New OleDbConnection
        Dim cmd As New OleDbCommand
        Try
            con.ConnectionString = "Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;"
            con.Open()
            cmd.Connection = con
            cmd.CommandText = "INSERT INTO tbl_VendorAddProduct([ProductID],[ProductName], [VendorName],[Qty],[ProductPrice],[Date],[Description],[TotalPrice]) VALUES(@ProductID, @ProductName, @VendorName, @Qty, @ProductPrice, @Date, @Description, @TotalPrice)"

            ' Control_Qty_Price()

            cmd.Parameters.AddWithValue("@ProductID", Me.txtProductID.Text)
            cmd.Parameters.AddWithValue("@ProductName", Me.txtProductName.Text)
            cmd.Parameters.AddWithValue("@VendorName", Me.txtVendorName.Text)
            cmd.Parameters.AddWithValue("@Qty", Me.txtProductQty1.Text)
            cmd.Parameters.AddWithValue("@ProductPrice", Me.txtProductPrice.Text)
            cmd.Parameters.AddWithValue("@Date", Me.txtDate.Text)
            cmd.Parameters.AddWithValue("@Description", Me.txtDescription.Text)
            cmd.Parameters.AddWithValue("@TotalPrice", Me.txtTotalPrice1.Text)

            cmd.ExecuteNonQuery()

            MsgBox("Add Data Successful On tbl_Vendor", MsgBoxStyle.OkOnly, "Message")
            RefreshData_tblVendorAddProduct()

        Catch ex As Exception
            MessageBox.Show("Error while inserting record on table..." & ex.Message, "Insert Records")
        Finally
            con.Close()
            RefreshData_tblVendorAddProduct()
            Update_tbl_Product()
        End Try
    End Sub

    Private Sub Update_tbl_Product()

        Dim con As New OleDbConnection
        Dim cmd As New OleDbCommand
        Try
            con.ConnectionString = "Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;"
            con.Open()
            cmd.Connection = con

            cmd.CommandText = "UPDATE tbl_Product SET ProductID = @ProductID, ProductName = @ProductName, VendorName = @VendorName, Qty = @Qty, Price = @Price, Description = @Description, TotalPrice = @TotalPrice Where ID = " & txtID.Text

            cmd.Parameters.AddWithValue("@ProductID", Me.txtProductID.Text)
            cmd.Parameters.AddWithValue("@ProductName", Me.txtProductName.Text)
            cmd.Parameters.AddWithValue("@VendorName", Me.txtVendorName.Text)
            cmd.Parameters.AddWithValue("@Qty", Me.txtProductQty.Text)
            cmd.Parameters.AddWithValue("@Price", Me.txtProductPrice.Text)
            cmd.Parameters.AddWithValue("@Description", Me.txtDescription.Text)
            cmd.Parameters.AddWithValue("@TotalPrice", Me.txtTotalPrice.Text)

            cmd.ExecuteNonQuery()


            '' MessageBox.Show("You data have been add new successful", "Information")

        Catch ex As Exception
            MessageBox.Show("Error while add new product..." & ex.Message, "Update Records")
        Finally
            con.Close()

        End Try

    End Sub

    Sub Calculate(ByVal Plus As Integer)

        Dim VID As String = txtID.Text
        Dim VProductID As String = txtProductID.Text
        Dim VProductName As String = txtProductName.Text
        Dim VVendorName As String = txtVendorName.Text

        Dim VQty As Double = CDbl(txtProductQty.Text)

        Dim VProductPrice As Double = CDbl(txtProductPrice.Text) 'Double' 
        Dim CurrentDate As String = txtDate.Text
        Dim VDescription As String = txtDescription.Text
        Dim VTotalPrice As String = txtTotalPrice.Text 'Maybe Double'

        Vendor_Product.txtProductID.Text = Me.txtProductID.Text
        Vendor_Product.txtProductName.Text = Me.txtProductName.Text
        Vendor_Product.txtVendorName.Text = Me.txtVendorName.Text

        'QTY
        Dim VendorQTY As Double = CDbl(Vendor_Product.txtProductQty.Text)
        txtProductQty.Text = CStr(VendorQTY + VQty)

        'SINGEL_PRICE
        'Dim VendorProductSingelPrice As Double = CDbl(Vendor_Add_Product.txtProductQty.Text)
        'txtProductPrice.Text = CStr(VendorProductSingelPrice + VProductPrice)

        Control_Qty_Price()

    End Sub

    Private Sub btnPlus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPlus.Click
        Try
            txtProductQty.Text = Me.txtProductQty1.Text
            CountTotalPrice()
            txtTotalPrice.Text = Me.txtTotalPrice1.Text
            Calculate(1)
            Add_Product()
        Catch ex As Exception
            MessageBox.Show("Pls make sure your type and select correct information", "Information")
        End Try

    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        Dim ID As String
        ID = txtID.Text

        txtID.Text = ID
        If txtID.Text = Nothing Then
            MessageBox.Show("Pls Select Data Correctly", "Information")
        Else
            HandleSetSettingStatus()
        End If

    End Sub

    Public Sub HandleSetSettingStatus()

        strFullDBPath = strCurrentPath + "\My_Data" + "\Shoppping_Cart.mdb"

        Dim connection As New OleDbConnection("Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;")
        Dim command As New OleDbCommand("DELETE FROM tbl_VendorAddProduct WHERE ID = @ID", connection)
        Select Case MsgBox("Did you sure you want to delete this data", MsgBoxStyle.YesNo, "Message Confirmation")
            Case MsgBoxResult.Yes
                MessageBox.Show("Your data have been deleted", "Message")
            Case MsgBoxResult.No
                MessageBox.Show("Your data have been keep", "Message")
                Exit Sub
        End Select
        MessageBox.Show("Delete data successful")
        command.Parameters.Add("@id", OleDbType.Char).Value = txtID.Text
        connection.Open()
        If command.ExecuteNonQuery() = 1 Then

        End If
        connection.Close()
        RefreshData_tblVendorAddProduct()
        btnClear.PerformClick()
    End Sub


    Private Sub DataGridView1_CellDoubleClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellDoubleClick
        'Me.btnSave.Text = "Update"
        'Me.btnSave.Enabled = True

        Me.txtID.Text = DataGridView1.CurrentRow.Cells("ID").Value.ToString
        Me.txtProductID.Text = DataGridView1.CurrentRow.Cells("ProductID").Value.ToString
        Me.txtProductName.Text = DataGridView1.CurrentRow.Cells("ProductName").Value.ToString
        Me.txtVendorName.Text = DataGridView1.CurrentRow.Cells("VendorName").Value.ToString
        Me.txtProductQty1.Text = DataGridView1.CurrentRow.Cells("Qty").Value.ToString
        Me.txtProductPrice.Text = DataGridView1.CurrentRow.Cells("ProductPrice").Value.ToString
        Me.txtDescription.Text = DataGridView1.CurrentRow.Cells("Description").Value.ToString
        Me.txtTotalPrice1.Text = DataGridView1.CurrentRow.Cells("TotalPrice").Value.ToString

        'btnSave.Enabled = True
        RefreshData_tblVendorAddProduct()
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        txtID.Text = ""
        txtProductID.Text = ""
        txtProductName.Text = ""
        txtVendorName.Text = ""
        txtProductQty.Text = ""
        txtProductQty1.Text = ""
        txtProductPrice.Text = ""
        txtDescription.Text = ""
        txtTotalPrice.Text = ""
        txtTotalPrice1.Text = ""
    End Sub

    Private Sub CountTotalPrice()
        Dim QTY1 As Integer = CInt(txtProductQty1.Text)
        Dim ProductPrice As Double = CDbl(txtProductPrice.Text)

        txtTotalPrice1.Text = CStr(QTY1 * ProductPrice)
        '' MessageBox.Show(txtTotalPrice1.Text)
    End Sub

    Private Sub txtSProductIDVendor_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtSProductIDVendor.TextChanged
        Dim cnn1 As New OleDb.OleDbConnection
        cnn1.ConnectionString = "Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;"
        If Not cnn1.State = ConnectionState.Open Then
        End If
        cnn1.Open()
        Dim dt As New DataTable
        Dim ds As New DataSet
        ds.Tables.Add(dt)
        Dim da As New OleDbDataAdapter

        da = New OleDbDataAdapter("SELECT * FROM tbl_VendorAddProduct WHERE ProductID like '%" & txtSProductIDVendor.Text & "%'", cnn1)
        da.Fill(dt)

        DataGridView1.DataSource = dt.DefaultView
        cnn1.Close()
    End Sub

    Private Sub txtSProductNameVendor_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtSProductNameVendor.TextChanged
        Dim cnn1 As New OleDb.OleDbConnection
        cnn1.ConnectionString = "Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;"
        If Not cnn1.State = ConnectionState.Open Then
        End If
        cnn1.Open()
        Dim dt As New DataTable
        Dim ds As New DataSet
        ds.Tables.Add(dt)
        Dim da As New OleDbDataAdapter

        da = New OleDbDataAdapter("SELECT * FROM tbl_VendorAddProduct WHERE ProductName like '%" & txtSProductNameVendor.Text & "%'", cnn1)
        da.Fill(dt)

        DataGridView1.DataSource = dt.DefaultView
        cnn1.Close()
    End Sub

    Private Sub btnConvertExcel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnConvertExcel.Click
        DataGridView1.Sort(DataGridView1.Columns(0), ListSortDirection.Ascending)

        MessageBox.Show("Pls wait a while", "Information")

        Dim xlapp As Microsoft.Office.Interop.Excel.Application
        Dim xlWorkBook As Microsoft.Office.Interop.Excel.Workbook
        Dim xlWorkSheet As Microsoft.Office.Interop.Excel.Worksheet
        Dim misValue As Object = System.Reflection.Missing.Value
        Dim i As Integer
        Dim j As Integer

        xlapp = New Microsoft.Office.Interop.Excel.Application
        xlWorkBook = xlapp.Workbooks.Add(misValue)
        xlWorkSheet = CType(xlWorkBook.Sheets("Sheet1"), Microsoft.Office.Interop.Excel.Worksheet)

        For k = 0 To DataGridView1.ColumnCount - 1
            xlWorkSheet.Cells(1, k + 1).HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter
            xlWorkSheet.Cells(1, k + 1) = DataGridView1.Columns(k).Name
        Next

        For i = 0 To DataGridView1.RowCount - 1
            For j = 0 To DataGridView1.ColumnCount - 1
                xlWorkSheet.Cells(i + 2, j + 1).HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter
                xlWorkSheet.Cells(i + 2, j + 1) =
                    DataGridView1(j, i).Value.ToString()
            Next
        Next

        Dim saveFileDialog1 As New SaveFileDialog()
        saveFileDialog1.Filter = "Execl files (*.xls)|*.xls"
        saveFileDialog1.FilterIndex = 2
        saveFileDialog1.RestoreDirectory = True
        If saveFileDialog1.ShowDialog() = DialogResult.OK Then
            xlWorkSheet.SaveAs(saveFileDialog1.FileName)
            MsgBox("Save file success")
        Else
            Return
        End If
        xlWorkBook.Close()
        xlapp.Quit()

        releaseObject(xlapp)
        releaseObject(xlWorkBook)
        releaseObject(xlWorkSheet)

        RefreshData_tblVendorAddProduct()
    End Sub

    Private Sub releaseObject(ByVal obj As Object)
        Try
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As Exception
            obj = Nothing
        Finally
            GC.Collect()
        End Try
    End Sub


End Class