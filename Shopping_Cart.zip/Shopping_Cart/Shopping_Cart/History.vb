﻿Imports System.Data.OleDb

Public Class History
    Dim strCurrentPath As String
    Public strFullDBPath As String
    Dim cmd As New OleDb.OleDbCommand
    Dim cn As New OleDbConnection
    'CONTROL DELETE ALL DGV DATA'
    Private dataStuff As List(Of String)


    Private Sub History_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.CenterToScreen()
        strCurrentPath = CurDir()
        strCurrentPath = Replace(CurDir, "\bin\Debug", "")
        strFullDBPath = strCurrentPath + "\My_Data" + "\Shoppping_Cart.mdb"
        cn.ConnectionString = "Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;"
        RefreshData_tblHistory()
    End Sub

   
    Private Sub RefreshData_tblHistory()
        Dim cn As New OleDbConnection("Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;")
        Dim Command As OleDbCommand = New OleDbCommand
        Command.CommandText = "SELECT * FROM tbl_History"
        Command.Connection = cn
        cn.Open()
        Dim dt As New DataTable
        dt.Load(Command.ExecuteReader())
        DataGridView1.DataSource = dt
    End Sub

    
    Private Sub DEBUG_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DEBUG.Click
        Dim con As OleDbConnection = New OleDbConnection("Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;")
        Dim cmd As OleDbCommand = New OleDbCommand("Delete * from tbl_History", con)
        con.Open()
        cmd.ExecuteNonQuery()
        con.Close()
        RefreshData_tblHistory()
    End Sub
End Class