﻿Imports System.Data.OleDb
Imports System.Data


Public Class User_Order
    Dim strCurrentPath As String
    Public strFullDBPath As String
    Dim cmd As New OleDb.OleDbCommand
    Dim cn As New OleDbConnection

    Private Sub User_Order_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.CenterToParent()
        txtDate.Text = DateTime.Now.ToString("dd  MMMM  yyyy")
        strCurrentPath = CurDir()
        strCurrentPath = Replace(CurDir, "\bin\Debug", "")
        strFullDBPath = strCurrentPath + "\My_Data" + "\Shoppping_Cart.mdb"
        cn.ConnectionString = "Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;"
        Count_Total()
        '   Me.BindGrid()

    End Sub

    Private Sub HandleSetSettingStatus()

        strFullDBPath = strCurrentPath + "\My_Data" + "\Shoppping_Cart.mdb"

        Dim connection As New OleDbConnection("Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;")

        Dim command As New OleDbCommand("DELETE FROM tbl_Cart WHERE ID = @ID", connection)

        MessageBox.Show("Pls Come Again")
        command.Parameters.Add("@id", OleDbType.Char).Value = Shopping_Cart.txtID.Text
        connection.Open()
        If command.ExecuteNonQuery() = 1 Then

        End If
        connection.Close()
        Count_Total()
    End Sub

    Private Sub Count_Total()
        If DataGridView2.RowCount > 0 Then
            Dim ITEM As Integer = 0
            Dim TOTALPRICE As Integer = 0

            'if you have the other column to get the result you  could add a new one like these above 
            For index As Integer = 0 To DataGridView2.RowCount - 1
                ITEM += Convert.ToInt32(DataGridView2.Rows(index).Cells(5).Value)
                TOTALPRICE += Convert.ToInt32(DataGridView2.Rows(index).Cells(7).Value)

                'if you have the other column to get the result you  could add a new one like these above (just change Cells(2) to the one you added)
            Next
            txtTotalItem.Text = CStr(ITEM)
            txtTotalPrice.Text = CStr(TOTALPRICE)

            'if you have the other column to get the result you  could add a new one like these above 
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If DataGridView2.RowCount > 0 Then
            Dim ITEM As Integer = 0
            Dim TOTALPRICE As Integer = 0

            'if you have the other column to get the result you  could add a new one like these above 
            For index As Integer = 0 To DataGridView2.RowCount - 1
                ITEM += Convert.ToInt32(DataGridView2.Rows(index).Cells(3).Value)
                TOTALPRICE += Convert.ToInt32(DataGridView2.Rows(index).Cells(5).Value)

                'if you have the other column to get the result you  could add a new one like these above (just change Cells(2) to the one you added)
            Next
            txtTotalItem.Text = CStr(ITEM)
            txtTotalPrice.Text = CStr(TOTALPRICE)

            'if you have the other column to get the result you  could add a new one like these above 
        End If
    End Sub

    Private Sub btnPayment_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPayment.Click
        Payment.txtTotalSales.Text = Me.txtTotalPrice.Text
        Payment.ShowDialog()

    End Sub
   
    Private Sub btnInsertRecord_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInsertRecord.Click
        For Each row As DataGridViewRow In DataGridView2.Rows
            Dim constring As String = "Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;"
            Using con As New OleDbConnection(constring)
                Using cmd As New OleDbCommand("INSERT INTO tbl_History VALUES(@ID, @ProductID, @ProductName, @CustomerName, @Cart_Qty, @Price, @Total_Price)", con)

                    cmd.Parameters.AddWithValue("@ID", row.Cells("ID").Value)
                    cmd.Parameters.AddWithValue("@ProductID", row.Cells("ProductID").Value)
                    cmd.Parameters.AddWithValue("@ProductName", row.Cells("ProductName").Value)
                    cmd.Parameters.AddWithValue("@CustomerName", row.Cells("CustomerName").Value)
                    cmd.Parameters.AddWithValue("@Cart_Qty", row.Cells("Cart_Qty").Value)
                    cmd.Parameters.AddWithValue("@Price", row.Cells("Price").Value)
                    cmd.Parameters.AddWithValue("@Total_Price", row.Cells("Total_Price").Value)
                    con.Open()
                    cmd.ExecuteNonQuery()
                    con.Close()
                End Using
            End Using
        Next
        MessageBox.Show("Records inserted.")
    End Sub

    Private Sub HomeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HomeToolStripMenuItem.Click
        Home.Show()
        Me.Close()
    End Sub
End Class