﻿Public Class Home

    Private Sub VendorToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles VendorToolStripMenuItem.Click
        Vendor_Product.ShowDialog()

    End Sub

    Private Sub VendorProductToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Vendor_Add_Stock.ShowDialog()

    End Sub

    Private Sub ShoppingCartToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ShoppingCartToolStripMenuItem.Click
        Product.ShowDialog()
    End Sub

    Private Sub UserOrderAndPaymentToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UserOrderAndPaymentToolStripMenuItem.Click
        Shopping_Cart.Show()
        Me.Hide()
    End Sub

    Private Sub Home_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.CenterToScreen()
    End Sub

    Private Sub Home_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

        Dim result As DialogResult
        result = MessageBox.Show("Are you sure you wish to close the program?", "Close program?", MessageBoxButtons.YesNo)

        If result = Windows.Forms.DialogResult.Yes Then
            e.Cancel = False
        Else
            e.Cancel = True
        End If

    End Sub

    Private Sub HistoryToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HistoryToolStripMenuItem.Click
        History.Show()
    End Sub
    
End Class