﻿Imports System.Data.OleDb

Public Class Payment

    Dim strCurrentPath As String
    Public strFullDBPath As String
    Dim cmd As New OleDb.OleDbCommand
    Dim cn As New OleDbConnection

    Private Sub Payment_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Me.CenterToScreen()
        strCurrentPath = CurDir()
        strCurrentPath = Replace(CurDir, "\bin\Debug", "")
        strFullDBPath = strCurrentPath + "\My_Data" + "\Shoppping_Cart.mdb"
        cn.ConnectionString = "Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;"
    End Sub

    Private Sub btnPay_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPay.Click
        Try
            Dim TotalSales As Double = CDbl(txtTotalSales.Text)
            Dim TotalPaymentAmount As Double = CDbl(txtTotalPaymentAmount.Text)

            If TotalPaymentAmount > TotalSales Or TotalPaymentAmount = TotalSales Then
                MessageBox.Show("You Payment Successful", "Information")
                User_Order.btnInsertRecord.PerformClick()
                Suceess_Sell()
                Shopping_Cart.Show()
                Me.Close()
            Else
                MessageBox.Show("Pls fill your amount", "Information")
                Exit Sub
            End If
        Catch ex As Exception

        End Try



    End Sub

    Private Sub txtTotalPaymentAmount_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtTotalPaymentAmount.KeyPress

        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) AndAlso e.KeyChar <> "."c Then
            e.Handled = True
        End If

        If e.KeyChar = "."c AndAlso (TryCast(sender, TextBox)).Text.IndexOf("."c) > -1 Then
            e.Handled = True
        End If
    End Sub



    Private Sub Suceess_Sell()
        Dim con As OleDbConnection = New OleDbConnection("Provider=Microsoft.Jet.Oledb.4.0; Data Source=" + strFullDBPath + ";Jet OLEDB:Database Password=123456;")
        Dim cmd As OleDbCommand = New OleDbCommand("Delete * from tbl_Cart", con)
        con.Open()
        cmd.ExecuteNonQuery()
        con.Close()
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Shopping_Cart.Show()
        Me.Close()

    End Sub
End Class